
import picture from "./picture.png";



import fireworks from "./fireworks.gif";
import christmas from "./christmas.gif";




export {

picture,
christmas,
fireworks,
};
